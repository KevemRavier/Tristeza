
// Online C++ Compiler - Build, Compile and Run your C++ programs online in your favorite browser

#include<iostream>

using namespace std;

int main()
{int Rola;
  cout << "Qual o tamanho da rola\n";
  cin >> Rola;
  cout << endl;
  if (Rola > 15){
  cout << "que piruzao ein gostoso, mete em mim" << endl;
  }
  else {
  cout << "que mixuruca, eca" << endl;
  }
  return 0;
  }
